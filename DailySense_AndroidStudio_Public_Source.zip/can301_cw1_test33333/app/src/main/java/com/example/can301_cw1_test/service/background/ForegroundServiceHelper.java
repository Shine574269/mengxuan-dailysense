package com.example.can301_cw1_test.service.background;

import android.app.Activity;
import android.content.Intent;
import com.example.can301_cw1_test.service.PerceptionService; // 你的原服务

/**
 * 前台服务启动/停止工具
 */
public class ForegroundServiceHelper {

    public static void start(Activity activity) {
        Intent intent = new Intent(activity, PerceptionService.class);
        activity.startService(intent);
    }

    public static void stop(Activity activity) {
        Intent intent = new Intent(activity, PerceptionService.class);
        activity.stopService(intent);
    }
}
