package com.example.can301_cw1_test.service.sensor;


import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/*
 传感器监听类：仅负责注册/注销传感器，采集原始加速度数据并传递给外部
 SensorEventListener 接口: Android 系统提供的传感器事件回调接口，必须实现 onSensorChanged（数据变化）和
 onAccuracyChanged（精度变化）方法
*/
public class SensorListener implements SensorEventListener {
    private StepCounter stepCounter;
    private final SensorManager sensorManager; // 传感器管理器（SensorManager类实例），用于管理系统传感器
    private final Sensor accelerometer; // 加速度传感器（Sensor类实例）
    private OnSensorDataListener dataListener; // dataListener 变量指向一个实现了接口 OnSensorDataListener的类的对象，用于调用 onDataReceived方法（接口 OnSensorDataListener的方法）将 SensorListener采集到的原始加速度数据传递给外部组件进行处理
                                               // dataListener 变量的类型是 OnSensorDataListener（一个接口），而接口本身不能直接创建对象

    // 构造方法：
    // 接收一个Context类参数context以获取系统的 SensorManager 服务，再通过该服务获取加速度传感器实例。
    public SensorListener(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);   // 获取一个SensorManager类实例以操作传感器

        // 获取加速度传感器（）
        // 判断传感器管理器（sensorManager）是否有效
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);  // 通过sensorManager实例获取加速度传感器实例
        } else {
            accelerometer = null;   // 若传感器管理器无效，将null赋值给accelerometer
        }
        // 初始化步数计算器
        stepCounter = new StepCounter();
    }

    // start方法：开始监听传感器
    public void start() {
        if (sensorManager != null && accelerometer != null) {
            // 注册监听
            /*
             this：监听器（实现了SensorEventListener接口类的对象，即调用该方法的SensorListener类的对象）
             accelerometer：要监听的传感器
             SENSOR_DELAY_NORMAL：默认延迟，约200毫秒更新一次数据
             */
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    // stop方法：停止监听
    public void stop() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    // onSensorChanged方法：接口方法，接收的参数为SensorEvent类实例event
    /*
     event： Android 系统传递的 “传感器事件（SensorEvent）对象”，封装了传感器的最新数据和相关信息，核心字段包括：
     event.sensor：当前产生数据的传感器实例，可通过 event.sensor.getType() 确认传感器类型。
     event.values：float[] 数组，存储传感器的原始数据。
     event.timestamp：数据产生的时间戳（单位：纳秒），用于记录数据采集的精确时间。
     */
    // 传感器数据变化时回调：将原始x/y/z轴数据通过接口传递
    // 传感器监听器被注册后，系统会在传感器数据更新时自动调用onSensorChanged方法
    @Override
    public void onSensorChanged(SensorEvent event) {
        // dataListener：实现了OnSensorDataListener接口的实例
        if (dataListener != null) {
            float x = event.values[0]; // x轴加速度
            float y = event.values[1]; // y轴加速度
            float z = event.values[2]; // z轴加速度
            dataListener.onDataReceived(x, y, z);   // 调用 onDataReceived方法将 SensorListener 采集到的原始加速度数据传递给外部组件进行处理
            // onDataReceived：OnSensorDataListener接口的方法

            // 新增：将加速度数据传递给步数计算器
            if (stepCounter != null) {
                stepCounter.processAcceleration(x, y, z);
            }
        }
    }

    // onAccuracyChanged方法：接口方法，无具体实现
    // 传感器精度变化时回调（无需处理）
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    // 设置数据回调监听器（由外部调用，如SensorService）
    /*
     SensorService中的的使用：
     SensorService中一个SensorListener实例调用该方法，传入一个实现了 OnSensorDataListener接口的类（SensorService中
     为一个内部匿名类）的实例，将该实例赋值给调用该方法的 SensorListener实例的变量 dataListener
     */
    public void setOnSensorDataListener(OnSensorDataListener listener) {
        this.dataListener = listener;
    }

    // 新增方法：暴露步数计算器的监听器设置
    public void setOnStepChangeListener(StepCounter.OnStepChangeListener listener) {
        if (stepCounter != null) {
            stepCounter.setOnStepChangeListener(listener);
        }
    }

    // 新增方法：获取当前步数
    public int getStepCount() {
        return stepCounter != null ? stepCounter.getStepCount() : 0;
    }

    // 新增方法：重置步数
    public void resetSteps() {
        if (stepCounter != null) {
            stepCounter.resetSteps();
        }
    }

    // OnSensorDataListener：内部接口
    /*
     定义传感器数据回调的接口，作为 SensorListener 与外部组件（如 SensorService）的数据传递桥梁。
     onDataReceived 方法接收 x、y、z 轴的加速度数据，由外部实现具体的处理逻辑（如状态判断）。
     */
    public interface OnSensorDataListener {
        void onDataReceived(float x, float y, float z);     // 约定数据传递的方式（即 “必须通过这个方法传递 x/y/z 轴数据”），无具体实现
    }
}
