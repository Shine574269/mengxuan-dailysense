package com.example.can301_cw1_test.ui;

import java.util.List;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.model.Behavior;
import com.example.can301_cw1_test.service.BehaviorDbHelper;

/**
 * 标签编辑页面：允许用户输入行为记录的文字描述
 */
public class TagEditActivity extends AppCompatActivity {
    private EditText tagEditText;
    private Button saveButton;
    private int behaviorId;
    private BehaviorDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tag_edit);

        // 获取传递的行为ID
        behaviorId = getIntent().getIntExtra("behavior_id", -1);
        if (behaviorId == -1) {
            finish();
            return;
        }

        dbHelper = new BehaviorDbHelper(this);
        tagEditText = findViewById(R.id.et_tag_input);
        saveButton = findViewById(R.id.btn_save_tag);

        // 加载现有标签
        new LoadTagTask().execute();

        // 保存标签
        saveButton.setOnClickListener(v -> {
            String tag = tagEditText.getText().toString().trim();
            new SaveTagTask(tag).execute();
        });
    }

    // 加载现有标签
    private class LoadTagTask extends AsyncTask<Void, Void, Behavior> {
        @Override
        protected Behavior doInBackground(Void... voids) {
            List<Behavior> behaviors = dbHelper.queryAll();
            for (Behavior b : behaviors) {
                if (b.getId() == behaviorId) {
                    return b;
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Behavior behavior) {
            if (behavior != null && behavior.getTag() != null) {
                tagEditText.setText(behavior.getTag());
            }
        }
    }

    // 保存标签到数据库
    private class SaveTagTask extends AsyncTask<Void, Void, Void> {
        private String tag;

        SaveTagTask(String tag) {
            this.tag = tag;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            List<Behavior> behaviors = dbHelper.queryAll();
            for (Behavior b : behaviors) {
                if (b.getId() == behaviorId) {
                    b.setTag(tag);
                    dbHelper.update(b);
                    break;
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            finish(); // 保存后返回历史页面
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) dbHelper.close();
    }
}