package com.example.can301_cw1_test.service;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

import com.example.can301_cw1_test.model.Behavior;


/*
 数据库操作类：仅负责Behavior表的创建、插入、更新
*/
public class BehaviorDbHelper extends SQLiteOpenHelper {
    // 数据库信息
    private static final String DB_NAME = "log_db"; // 数据库文件名
    private static final int DB_VERSION = 2; // 版本号
    private static final String TABLE_BEHAVIOR = "behavior"; // 表名

    // 构造方法
    public BehaviorDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // 首次创建数据库时调用：创建behavior表
    @Override
    public void onCreate(SQLiteDatabase db) {
        //拼接sql语句
        String createTableSql = "CREATE TABLE " + TABLE_BEHAVIOR + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," + // （AUTOINCREMENT）主键（PRIMARY KEY）
                "type TEXT NOT NULL," + // 状态类型（STILL/MOVING）
                "startTime LONG NOT NULL," + // 开始时间戳
                "endTime LONG," + // 结束时间戳（可为null）
                "tag TEXT," + // 用户标签（可为null）
                "latitude REAL," + // 纬度字段
                "longitude REAL" +  // 经度字段
                ")";

        db.execSQL(createTableSql);     //执行拼接的sql语句，在数据库中创建behavior表
    }


    // ========== 新增方法：按时间戳范围查询行为数据 ==========
    public List<Behavior> getBehaviorsByTimeRange(long startTime, long endTime) {
        List<Behavior> behaviorList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;

        try {
            // 查询条件：startTime BETWEEN 起始时间 AND 结束时间
            String selection = "startTime BETWEEN ? AND ?";
            String[] selectionArgs = {String.valueOf(startTime), String.valueOf(endTime)};

            cursor = db.query(
                    TABLE_BEHAVIOR,
                    null,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    "startTime ASC" // 按开始时间正序
            );

            // 解析Cursor为Behavior列表（和queryAll()逻辑一致）
            while (cursor.moveToNext()) {
                Behavior behavior = new Behavior();
                behavior.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                behavior.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                behavior.setStartTime(cursor.getLong(cursor.getColumnIndexOrThrow("startTime")));

                // 处理可为null的字段
                int endTimeIndex = cursor.getColumnIndex("endTime");
                if (!cursor.isNull(endTimeIndex)) {
                    behavior.setEndTime(cursor.getLong(endTimeIndex));
                }
                int tagIndex = cursor.getColumnIndex("tag");
                if (!cursor.isNull(tagIndex)) {
                    behavior.setTag(cursor.getString(tagIndex));
                }
                // 经纬度
                int latIndex = cursor.getColumnIndex("latitude");
                if (!cursor.isNull(latIndex)) {
                    behavior.setLatitude(cursor.getDouble(latIndex));
                }
                int lonIndex = cursor.getColumnIndex("longitude");
                if (!cursor.isNull(lonIndex)) {
                    behavior.setLongitude(cursor.getDouble(lonIndex));
                }

                behaviorList.add(behavior);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return behaviorList;
    }

    // 数据库版本升级
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // 升级时添加新字段
            db.execSQL("ALTER TABLE " + TABLE_BEHAVIOR + " ADD COLUMN latitude REAL");
            db.execSQL("ALTER TABLE " + TABLE_BEHAVIOR + " ADD COLUMN longitude REAL");
        }
    }

    // 插入一条行为记录(将一个Behavior类对象存入behavior表中)
    // 接受一个Behavior类对象（将被存入behavior表中的Behavior类对象），返回插入的记录ID（long）
    public long insert(Behavior behavior) {
        SQLiteDatabase db = getWritableDatabase();  // 获取一个sql实例用于进行增删改查操作
        ContentValues values = new ContentValues(); // 创建ContentValues类对象values，存储数据（形式：字段-值）
        // 向values中存入数据
        values.put("type", behavior.getType()); // values的type字段对应当前Behavior类对象（将被加入behavior表中的对象）的type
        values.put("startTime", behavior.getStartTime());   // values的startTime字段对应当前Behavior类对象（将被加入behavior表中的对象）的startTime
        values.put("endTime", behavior.getEndTime()); // 可为null（新状态刚开始时）
        values.put("tag", behavior.getTag()); // 可为null（初始无标签）
        values.put("latitude", behavior.getLatitude()); // 新增纬度
        values.put("longitude", behavior.getLongitude()); // 新增经度

        // 插入数据并返回记录ID（-1表示失败）
        long rowId = db.insert(TABLE_BEHAVIOR, null, values);
        db.close(); // 关闭数据库连接
        return rowId;
    }

    // 更新行为记录（主要用于补全endTime）
    // 接受一个Behavior类对象（要被更新endtime的Behavior类对象）
    public void update(Behavior behavior) {
        SQLiteDatabase db = getWritableDatabase();      // 获取一个sql实例用于进行增删改查操作
        ContentValues values = new ContentValues();     // 创建ContentValues类对象values，存储数据（形式：字段-值）

        values.put("endTime", behavior.getEndTime()); // 只将结束时间加入values
        values.put("tag", behavior.getTag()); // 更新标签
        values.put("latitude", behavior.getLatitude()); // 更新经纬度
        values.put("longitude", behavior.getLongitude());

        // 仅更新id与behavior.getId()匹配的记录的字段
        /*
        db.update方法更新数据：
        参数 1：目标表名TABLE_BEHAVIOR。
        参数 2：values（要更新的字段和值）。
        参数 3：whereClause（更新条件："id = ?"，?为占位符）。
        参数 4：whereArgs（占位符的实际值，这里是调用该方法的behavior（要被更新endtime的Behavior类对象）的id，需转为字符串数组）。
         */
        db.update(
                TABLE_BEHAVIOR,
                values,
                "id = ?",
                new String[]{String.valueOf(behavior.getId())}
        );
        db.close(); // 关闭数据库连接
    }

    // 删除
    public int delete(int id) {
        SQLiteDatabase db = getWritableDatabase();
        //db.delete(TABLE_BEHAVIOR, "id = ?", new String[]{String.valueOf(id)});
        // 声明变量 + 接收delete方法的返回值（删除的行数）
        int rowsDeleted = db.delete(TABLE_BEHAVIOR, "id = ?", new String[]{String.valueOf(id)});
        db.close();
        return rowsDeleted; // 返回删除的行数
    }


    //
    public List<Behavior> queryAll() {
        List<Behavior> behaviorList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;

        try {
            // 替换TABLE_BEHAVIOR为你项目中定义的表名（确保一致）
            cursor = db.query(
                    TABLE_BEHAVIOR,  // 你的行为表名
                    null,
                    null,
                    null,
                    null,
                    null,
                    "startTime DESC" // 按开始时间倒序
            );

            while (cursor.moveToNext()) {
                Behavior behavior = new Behavior();
                // 以下字段名（id/type/startTime等）需和你建表时的列名完全一致！
                behavior.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                behavior.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
                behavior.setStartTime(cursor.getLong(cursor.getColumnIndexOrThrow("startTime")));

                // 处理可为null的字段（endTime/tag）
                int endTimeIndex = cursor.getColumnIndex("endTime");
                if (!cursor.isNull(endTimeIndex)) {
                    behavior.setEndTime(cursor.getLong(endTimeIndex));
                }

                int tagIndex = cursor.getColumnIndex("tag");
                if (!cursor.isNull(tagIndex)) {
                    behavior.setTag(cursor.getString(tagIndex));
                }

                // 经纬度
                int latIndex = cursor.getColumnIndex("latitude");
                if (!cursor.isNull(latIndex)) {
                    behavior.setLatitude(cursor.getDouble(latIndex));
                }

                int lonIndex = cursor.getColumnIndex("longitude");
                if (!cursor.isNull(lonIndex)) {
                    behavior.setLongitude(cursor.getDouble(lonIndex));
                }

                behaviorList.add(behavior);
            }
        } catch (Exception e) {
            e.printStackTrace(); // 捕获异常，避免崩溃
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return behaviorList;
    }
}
