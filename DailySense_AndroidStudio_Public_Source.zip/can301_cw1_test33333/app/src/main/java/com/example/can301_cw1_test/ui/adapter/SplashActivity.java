package com.example.can301_cw1_test.ui.adapter;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.ui.MainActivity;

public class SplashActivity extends AppCompatActivity {
    private static final String TAG = "SplashActivity";
    private static final long SPLASH_DURATION = 2500;
    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Log.d(TAG, "启动页 onCreate 执行");

        mHandler = new Handler(Looper.getMainLooper());
        mHandler.postDelayed(() -> {
            Log.d(TAG, "准备跳转到 MainActivity");
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

            // 添加淡入淡出过渡动画（关键！）
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

            finish();
            Log.d(TAG, "启动页已关闭");
        }, SPLASH_DURATION);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
    }
}