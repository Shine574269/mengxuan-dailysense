package com.example.can301_cw1_test.service;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.can301_cw1_test.model.Behavior;
import com.example.can301_cw1_test.service.location.LocationJudge;
import com.example.can301_cw1_test.service.location.LocationService;
import com.example.can301_cw1_test.service.sensor.SensorListener;
import com.example.can301_cw1_test.service.sensor.StepCounter;
import com.example.can301_cw1_test.util.ServiceNotificationHelper;
import com.example.can301_cw1_test.util.PermissionUtil;

import java.util.List;

/** 感知服务：协调传感器、定位模块，记录行为状态 */
public class PerceptionService extends Service {
    private static final String TAG = "PerceptionService";

    // 核心组件
    private SensorListener sensorListener;
    private LocationService locationService;
    private LocationJudge locationJudge;
    private BehaviorDbHelper dbHelper;
    private Behavior currentBehavior;

    // Binder用于Activity绑定服务
    private final IBinder binder = new LocalBinder();

    // 本地Binder类
    public class LocalBinder extends Binder {
        public PerceptionService getService() {
            return PerceptionService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "服务启动，初始化组件");

        // 权限前置检查
        if (!checkRequiredPermissions()) {
            Log.e(TAG, "缺少必要权限，停止服务启动");
            // 容错：先启动前台服务再停止
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification notification = ServiceNotificationHelper.create(this, "服务启动失败");
                startForeground(ServiceNotificationHelper.NOTIFICATION_ID, notification);
            }
            stopSelf();
            return;
        }

        // 适配ServiceNotificationHelper
        Notification notification = null;
        try {
            // 使用工具类创建通知
            notification = ServiceNotificationHelper.create(this, "后台感知运行中");
            // 启动前台服务（捕获SecurityException）
            startForeground(ServiceNotificationHelper.NOTIFICATION_ID, notification);
        } catch (SecurityException e) {
            Log.e(TAG, "启动前台服务失败：", e);
            stopSelf();
            return;
        } catch (Exception e) {
            Log.e(TAG, "创建通知失败：", e);
            stopSelf();
            return;
        }

        // 初始化数据库并修复未完成记录
        dbHelper = new BehaviorDbHelper(this);
        new FixUnfinishedRecordsTask().execute();
    }

    // 复用PermissionUtil检查权限
// PerceptionService.java 中修改 checkRequiredPermissions 方法
    private boolean checkRequiredPermissions() {
        // 1. 仅将传感器权限作为计步的必要条件
        boolean hasSensorPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS)
                == PackageManager.PERMISSION_GRANTED;
        if (!hasSensorPermission) {
            Log.e(TAG, "缺少传感器权限，计步功能不可用");
            return false; // 传感器权限缺失才终止服务
        }

        // 2. 定位权限改为可选，仅警告不终止
        boolean hasLocationPermission = PermissionUtil.checkLocationPermissions(this);
        if (!hasLocationPermission) {
            Log.w(TAG, "缺少定位权限，定位功能不可用，计步功能仍可正常运行");
            // 不终止服务，仅跳过定位初始化
            locationService = null;
        } else {
            locationService = new LocationService(this); // 正常初始化定位
        }

        return true;
    }

    // 服务重启策略
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 服务被杀死后自动重启，且保留Intent
        return START_REDELIVER_INTENT;
    }

    // 提供给外部获取当前步数的方法
    public int getStepCount() {
        if (sensorListener != null) {
            return sensorListener.getStepCount();
        }
        return 0;
    }

    // 提供给外部重置步数的方法
    public void resetSteps() {
        if (sensorListener != null) {
            sensorListener.resetSteps();
        }
    }

    // 修复未完成的行为记录
    private class FixUnfinishedRecordsTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            List<Behavior> allBehaviors = dbHelper.queryAll();
            long serviceStartTime = System.currentTimeMillis();
            for (Behavior behavior : allBehaviors) {
                if (behavior.getEndTime() == null) {
                    behavior.setEndTime(serviceStartTime);
                    dbHelper.update(behavior);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            initSensorModule();
            initLocationModule();
        }
    }

    // 初始化传感器模块（加异常防护）
    private void initSensorModule() {
        try {
            sensorListener = new SensorListener(this);
            sensorListener.setOnSensorDataListener((x, y, z) -> {
                // 传感器数据处理逻辑
            });

            // 步数监听器
            sensorListener.setOnStepChangeListener(totalSteps -> {
                Log.d(TAG, "当前步数：" + totalSteps);
                // 实时更新通知步数
                ServiceNotificationHelper.update(this, "当前步数：" + totalSteps);
            });

            sensorListener.start();
        } catch (Exception e) {
            Log.e(TAG, "初始化传感器失败：", e);
        }
    }

    // 初始化定位模块（加权限双重检查）
    private void initLocationModule() {
        if (!PermissionUtil.checkLocationPermissions(this)) {
            Log.e(TAG, "定位权限不足，跳过定位初始化");
            return;
        }

        try {
            locationService = new LocationService(this);
            locationJudge = new LocationJudge();

            locationService.setOnLocationUpdateListener((lat, lon) -> {
                locationJudge.processLocation(lat, lon);
            });

            locationJudge.setOnLocationStateChangeListener((newState, lat, lon) -> {
                handleStateChange(newState, lat, lon);
                // 实时更新通知位置状态
                ServiceNotificationHelper.update(this, "当前状态：" + newState);
            });

            locationService.startLocationUpdates();
        } catch (SecurityException e) {
            Log.e(TAG, "启动定位更新失败（权限不足）：", e);
        } catch (Exception e) {
            Log.e(TAG, "初始化定位模块失败：", e);
        }
    }

    // 处理状态变化（保存行为记录）
    private void handleStateChange(String newState, double latitude, double longitude) {
        Log.d(TAG, "状态变为：" + newState + "，位置：" + latitude + "," + longitude);

        if (currentBehavior != null) {
            currentBehavior.setEndTime(System.currentTimeMillis());
            dbHelper.update(currentBehavior);
        }

        currentBehavior = new Behavior(newState, System.currentTimeMillis(), latitude, longitude);
        long newId = dbHelper.insert(currentBehavior);
        currentBehavior.setId((int) newId);
    }

    // 完善资源释放
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "服务停止，释放资源");

        // 停止传感器
        if (sensorListener != null) {
            sensorListener.stop();
            sensorListener = null;
        }

        // 停止定位
        if (locationService != null) {
            locationService.stopLocationUpdates();
            locationService = null;
        }

        // 保存最后一条记录
        if (currentBehavior != null) {
            currentBehavior.setEndTime(System.currentTimeMillis());
            dbHelper.update(currentBehavior);
        }

        // 关闭数据库
        if (dbHelper != null) {
            dbHelper.close();
            dbHelper = null;
        }

        // 停止前台服务并移除通知
        stopForeground(STOP_FOREGROUND_REMOVE);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}