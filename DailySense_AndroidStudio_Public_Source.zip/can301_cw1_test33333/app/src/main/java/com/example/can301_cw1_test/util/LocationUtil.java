package com.example.can301_cw1_test.util;

import android.location.Location;

/**
 * 定位工具类：经纬度处理、距离计算等
 */
public class LocationUtil {

    /**
     * 计算两点之间的距离（米）
     * @param lat1 点1纬度
     * @param lon1 点1经度
     * @param lat2 点2纬度
     * @param lon2 点2经度
     * @return 距离（米）
     */
    public static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        float[] results = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, results);
        return results[0]; // 单位：米
    }

    /**
     * 格式化经纬度（保留6位小数）
     * @param lat 纬度
     * @param lon 经度
     * @return 格式化字符串（如：39.908701, 116.397500）
     */
    public static String formatLatLng(double lat, double lon) {
        return String.format("%.6f, %.6f", lat, lon);
    }

    /**
     * 验证纬度是否有效（范围：[-90, 90]）
     * @param latitude 纬度值
     * @return 是否有效
     */
    public static boolean isValidLatitude(double latitude) {
        return latitude >= -90 && latitude <= 90;
    }

    /**
     * 验证经度是否有效（范围：[-180, 180]）
     * @param longitude 经度值
     * @return 是否有效
     */
    public static boolean isValidLongitude(double longitude) {
        return longitude >= -180 && longitude <= 180;
    }

    /**
     * 判断定位精度是否可用（精度 <= 100米视为可用）
     * @param location 定位信息
     * @return 是否可用
     */
    public static boolean isLocationAccurate(Location location) {
        return location != null && location.getAccuracy() <= 100;
    }
}
