package com.example.can301_cw1_test.model;

public class Schedule {
    private int id;
    private String title;
    private String target;
    private String date;
    private boolean completed;
    private long createdTime;

    // 无参构造函数
    public Schedule() {
    }

    // 带参构造函数
    public Schedule(String title, String target, String date, boolean completed) {
        this.title = title;
        this.target = target;
        this.date = date;
        this.completed = completed;
        this.createdTime = System.currentTimeMillis();
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public String toString() {
        return "Schedule{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", target='" + target + '\'' +
                ", date='" + date + '\'' +
                ", completed=" + completed +
                ", createdTime=" + createdTime +
                '}';
    }
}