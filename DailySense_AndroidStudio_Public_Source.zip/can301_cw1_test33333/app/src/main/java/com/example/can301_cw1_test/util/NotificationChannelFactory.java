package com.example.can301_cw1_test.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

public class NotificationChannelFactory {
    public static final String CHANNEL_ID = "perception_service";

    public static void createIfNeeded(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "后台感知",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("实时显示后台感知服务运行状态");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
}
