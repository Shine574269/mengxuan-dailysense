package com.example.can301_cw1_test.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

// 导入你的Behavior类
import com.example.can301_cw1_test.model.Behavior;

public class BehaviorAdapter extends BaseAdapter {
    private Context context;
    private List<Behavior> behaviorList;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private OnTimeStampClickListener listener;


    // 构造方法
    public BehaviorAdapter(Context context, List<Behavior> behaviorList) {
        this.context = context;
        this.behaviorList = behaviorList;
    }

    // 构造方法（接收三个参数：上下文、数据列表、点击监听器）
    public BehaviorAdapter(Context context, List<Behavior> behaviorList, OnTimeStampClickListener listener) {
        this.context = context;
        this.behaviorList = behaviorList;
        this.listener = listener;
    }

    // 在 BehaviorAdapter 类中添加接口定义
    public interface OnTimeStampClickListener {
        void onTimeStampClick(View view, Behavior behavior);
    }

    @Override
    public int getCount() {
        return behaviorList == null ? 0 : behaviorList.size();
    }

    @Override
    public Object getItem(int position) {
        return behaviorList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return behaviorList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        // 复用View，提升性能
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            holder = new ViewHolder();
            holder.title = convertView.findViewById(android.R.id.text1);
            holder.content = convertView.findViewById(android.R.id.text2);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        // 绑定数据
        Behavior behavior = behaviorList.get(position);
        holder.title.setText("状态类型：" + behavior.getType());

        // 时间格式化
        String startTime = sdf.format(new Date(behavior.getStartTime()));
        // 修复endTime空指针问题
        Long endTimeLong = behavior.getEndTime();
        String endTime = (endTimeLong == null || endTimeLong == 0) ? "未结束" : sdf.format(new Date(endTimeLong));
        holder.content.setText("开始时间：" + startTime + " | 结束时间：" + endTime);

        // 只给时间戳文本（content）设置点击事件
        holder.content.setOnClickListener(v -> {
            if (listener != null) {
                listener.onTimeStampClick(v, behaviorList.get(position));
            }
        });

        return convertView;
    }

    // 删除方法
    public void remove(int position) {
        if (behaviorList != null && position >= 0 && position < behaviorList.size()) {
            behaviorList.remove(position);
            notifyDataSetChanged(); // 通知列表刷新
        }
    }

    // ViewHolder优化
    static class ViewHolder {
        TextView title;
        TextView content;
    }
}
