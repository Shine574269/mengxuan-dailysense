// model/AIRequest.java
package com.example.can301_cw1_test.model;

import java.util.List;

public class AIRequest {
    private List<Behavior> behaviors;
    private String userMood;      // 用户当前的情绪状态
    private String language = "zh-CN";

    // 用于ApiUtil的行为类型标签
    private String behaviorTag;   // 行为类型标签
    private long startTime;
    private long endTime;

    // 构造方法初始化主要数据
    public AIRequest(List<Behavior> behaviors, String userMood) {
        this.behaviors = behaviors;
        this.userMood = userMood;

        // 初始化行为的时间信息
        if (behaviors != null && !behaviors.isEmpty()) {
            this.behaviorTag = generateBehaviorTag(behaviors);
            this.startTime = extractStartTime(behaviors);
            this.endTime = extractEndTime(behaviors);
        }
    }

    // 生成行为类型标签，根据行为中移动和静止的行为数量
    private String generateBehaviorTag(List<Behavior> behaviors) {
        if (behaviors == null || behaviors.isEmpty()) {
            return "无任何行为";
        }

        // 统计各类行为数量
        int movingCount = 0;
        int stillCount = 0;

        for (Behavior behavior : behaviors) {
            if ("MOVING".equals(behavior.getType())) {
                movingCount++;
            } else if ("STILL".equals(behavior.getType())) {
                stillCount++;
            }
        }

        if (movingCount > stillCount) {
            return "移动类行为较多";
        } else if (stillCount > movingCount) {
            return "静止类行为较多";
        } else {
            return "两种行为均衡";
        }
    }

    // 提取最早的开始时间
    private long extractStartTime(List<Behavior> behaviors) {
        long earliest = Long.MAX_VALUE;
        for (Behavior b : behaviors) {
            // 注意：getStartTime() 返回 long，不能与 null 比较
            // 直接比较值即可，因为 long 永远不会为 null
            if (b.getStartTime() < earliest) {
                earliest = b.getStartTime();
            }
        }
        return earliest != Long.MAX_VALUE ? earliest : System.currentTimeMillis();
    }

    // 提取最晚的结束时间
    private long extractEndTime(List<Behavior> behaviors) {
        long latest = 0;
        for (Behavior b : behaviors) {
            // endTime 是 Long，需要检查是否为 null
            Long endTime = b.getEndTime();
            if (endTime != null && endTime > latest) {
                latest = endTime;
            } else if (b.getStartTime() > latest) {
                // startTime 是 long，直接使用
                latest = b.getStartTime();
            }
        }
        return latest != 0 ? latest : System.currentTimeMillis();
    }

    // Getter和Setter方法
    public List<Behavior> getBehaviors() { return behaviors; }
    public void setBehaviors(List<Behavior> behaviors) { this.behaviors = behaviors; }

    public String getUserMood() { return userMood; }
    public void setUserMood(String userMood) { this.userMood = userMood; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    // 用于ApiUtil的getter方法
    public String getBehaviorTag() { return behaviorTag; }
    public long getStartTime() { return startTime; }
    public long getEndTime() { return endTime; }
}