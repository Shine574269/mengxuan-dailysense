package com.example.can301_cw1_test.util;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;

public class CircularProgressView extends View {
    private Paint backgroundPaint;
    private Paint progressPaint;
    private Paint textPaint;

    private float progress = 0;
    private int backgroundColor = Color.parseColor("#E0E0E0");
    private int progressColor = Color.parseColor("#F09647");
    private int textColor = Color.parseColor("#333333");

    public CircularProgressView(Context context) {
        super(context);
        init();
    }

    public CircularProgressView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CircularProgressView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // 背景圆环画笔
        backgroundPaint = new Paint();
        backgroundPaint.setColor(backgroundColor);
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(8);
        backgroundPaint.setAntiAlias(true);

        // 进度圆环画笔
        progressPaint = new Paint();
        progressPaint.setColor(progressColor);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(8);
        progressPaint.setAntiAlias(true);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);

        // 文字画笔
        textPaint = new Paint();
        textPaint.setColor(textColor);
        textPaint.setTextSize(16);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        int centerX = width / 2;
        int centerY = height / 2;
        int radius = Math.min(width, height) / 2 - 10;

        RectF rectF = new RectF(centerX - radius, centerY - radius, centerX + radius, centerY + radius);

        // 绘制背景圆环
        canvas.drawArc(rectF, 0, 360, false, backgroundPaint);

        // 绘制进度圆环
        if (progress > 0) {
            float sweepAngle = 360 * progress / 100;
            canvas.drawArc(rectF, -90, sweepAngle, false, progressPaint);
        }

        // 绘制进度文字
        String progressText = String.format("%d%%", (int) progress);
        Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
        float textHeight = fontMetrics.descent - fontMetrics.ascent;
        float textY = centerY + (textHeight / 2) - fontMetrics.descent;
        canvas.drawText(progressText, centerX, textY, textPaint);
    }

    public void setProgress(float progress) {
        this.progress = Math.min(progress, 100);
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    public void setProgressColor(int color) {
        progressPaint.setColor(color);
        invalidate();
    }

    public void setBackgroundColor(int color) {
        backgroundPaint.setColor(color);
        invalidate();
    }

    public void setTextColor(int color) {
        textPaint.setColor(color);
        invalidate();
    }
}