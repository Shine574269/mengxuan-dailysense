package com.example.can301_cw1_test.util;

import android.text.format.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * 时间工具类：处理时间戳格式化、时长计算等
 */
public class TimeUtil {

    /**
     * 时间戳转标准格式字符串（yyyy-MM-dd HH:mm:ss）
     * @param timestamp 时间戳（毫秒）
     * @return 格式化化后的时间字符串
     */
    public static String formatTimestamp(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    /**
     * 时间戳转日历格式（yyyy年MM月dd日 星期X）
     * @param timestamp 时间戳（毫秒）
     * @return 日历格式字符串
     */
    public static String formatCalendar(long timestamp) {
        return DateFormat.format("yyyy年MM月dd日 EEEE", timestamp).toString();
    }

    /**
     * 计算两个时间戳的差值（时:分:秒）
     * @param startTime 开始时间戳（毫秒）
     * @param endTime 结束时间戳（毫秒）
     * @return 格式化的时长字符串
     */
    public static String calculateDuration(long startTime, long endTime) {
        long duration = endTime - startTime;
        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) % 60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
    }

    /**
     * 计算两个时间戳的差值（分钟数）
     * @param startTime 开始时间戳（毫秒）
     * @param endTime 结束时间戳（毫秒）
     * @return 分钟数
     */
    public static long getDurationMinutes(long startTime, long endTime) {
        return TimeUnit.MILLISECONDS.toMinutes(endTime - startTime);
    }

    public static long getTodayStartTime() {
        // 直接使用系统的Calendar类
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0); // 小时设为0点
        calendar.set(Calendar.MINUTE, 0);      // 分钟设为0
        calendar.set(Calendar.SECOND, 0);      // 秒设为0
        calendar.set(Calendar.MILLISECOND, 0); // 毫秒设为0
        return calendar.getTimeInMillis();     // 返回今日起始时间戳
    }


}
