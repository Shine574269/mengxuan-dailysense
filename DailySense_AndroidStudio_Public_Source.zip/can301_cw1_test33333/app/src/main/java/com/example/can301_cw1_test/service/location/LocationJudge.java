package com.example.can301_cw1_test.service.location;

import com.example.can301_cw1_test.util.LocationUtil;

/*
 定位状态判断：根据经纬度变化判断移动/未移动
 */
public class LocationJudge {
    // 状态常量
    public static final String STATE_COMMUTING = "MOVING"; // 移动中
    public static final String STATE_NOT_MOVING = "NOT_MOVING"; // 未移动

    // 判定参数
    private static final double DISTANCE_THRESHOLD = 50; // 移动距离达到50米判定为移动
    private static final long COMMUTE_CONFIRM_DURATION = 120000; // 120秒持续移动判定为移动

    // 历史位置
    private double lastLatitude;
    private double lastLongitude;
    private boolean hasHistoryLocation = false;

    // 状态跟踪
    private String currentState = STATE_NOT_MOVING;
    private long commutingStartTime = 0;

    private OnLocationStateChangeListener stateListener;

    // 处理新位置数据
    // 每次 LocationService更新位置信息（时间经过 60秒）时被调用
    public void processLocation(double latitude, double longitude) {
        // 首次调用时（无历史位置记录）：
        if (!hasHistoryLocation) {
            // 首次获取位置，初始化数据
            lastLatitude = latitude;
            lastLongitude = longitude;
            hasHistoryLocation = true;
            return;
        }

        // 调用 LocationUtil类的方法计算与上次位置的距离（米）
        double distance = LocationUtil.calculateDistance(
                lastLatitude, lastLongitude,
                latitude, longitude
        );

        // 更新历史位置
        lastLatitude = latitude;
        lastLongitude = longitude;

        long currentTime = System.currentTimeMillis();  // 获取当前系统时间戳（毫秒级），用于计算移动持续时间

        boolean isMoving; // 声明变量 isMoving：用于存储是否在移动的判断结果
        // 判断当前距离是否达到或超过设定的阈值（50米）
        if (distance >= DISTANCE_THRESHOLD) {
            // 如果距离≥30米，说明处于移动状态，赋值为true
            isMoving = true;
        } else {
            // 如果距离<30米，说明未处于移动状态，赋值为false
            isMoving = false;
        }
        // 状态判定逻辑
        String newState = currentState;
        if (isMoving) {
            // 检测到移动
            if (commutingStartTime == 0) {
                commutingStartTime = currentTime;
            }
            // 持续移动超过阈值，判定为通勤
            if (currentTime - commutingStartTime >= COMMUTE_CONFIRM_DURATION) {
                newState = STATE_COMMUTING;
            }
        } else {
            // 未移动，重置计时
            commutingStartTime = 0;
            newState = STATE_NOT_MOVING;
        }

        // 状态变化时通知
        if (!newState.equals(currentState)) {
            currentState = newState;
            if (stateListener != null) {
                stateListener.onLocationStateChanged(currentState, latitude, longitude);
            }
        }
    }

    // 设置状态变化监听器
    public void setOnLocationStateChangeListener(OnLocationStateChangeListener listener) {
        this.stateListener = listener;
    }

    // 定位状态变化回调接口（携带经纬度）
    public interface OnLocationStateChangeListener {
        void onLocationStateChanged(String newState, double latitude, double longitude);
    }
}