package com.example.can301_cw1_test.service.background;

import android.app.Activity;
import android.os.Build;
import androidx.annotation.RequiresApi;
import com.example.can301_cw1_test.service.background.BatteryOptHelper;
import com.example.can301_cw1_test.service.background.ForegroundServiceHelper;

public class BackgroundManager {

    /**
     * 在 Activity 内调用，顺序：
     * 1. 创建通知渠道
     * 2. 启动前台服务
     * 3. 申请电池白名单
     */
    public static void applyAll(Activity activity) {
        // 1. 渠道
        NotificationChannelFactory.createChannelIfNeeded(activity);

        // 2. 前台服务
        ForegroundServiceHelper.start(activity);

        // 3. 电池白名单（Android M+）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            BatteryOptHelper.requestIgnoreBatteryOptimizations(activity);
        }
    }

    /**
     * App 退出时调用
     */
    public static void release(Activity activity) {
        ForegroundServiceHelper.stop(activity);
    }
}
