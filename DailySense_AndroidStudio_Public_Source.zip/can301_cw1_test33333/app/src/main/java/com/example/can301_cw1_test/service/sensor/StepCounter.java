// filePath: can301_cw1_test/service/sensor/StepCounter.java
package com.example.can301_cw1_test.service.sensor;

import android.util.Log;

/**
 * 步数计算器：基于加速度传感器数据计算步数
 */
public class StepCounter {
    private static final String TAG = "StepCounter";

    // 计步核心参数（可根据实际情况调整）
    private static final float STEP_THRESHOLD = 0.8f; // 步数检测阈值
    private static final long STEP_INTERVAL = 500; // 步与步之间的最小时间间隔(毫秒)

    private int stepCount = 0; // 当前步数
    private long lastStepTime = 0; // 上一步的时间戳
    private float lastMagnitude = 0; // 上一次的加速度值
    private boolean isPeakDetected = false; // 是否检测到峰值

    private OnStepChangeListener stepListener; // 步数变化监听器

    // 处理加速度数据，检测步数
    public void processAcceleration(float x, float y, float z) {
        // 计算加速度的合向量（排除重力影响的简化处理）
        float magnitude = (float) Math.sqrt(x*x + y*y + z*z);
        // 计算与上一次的差值
        float delta = Math.abs(magnitude - lastMagnitude);
        lastMagnitude = magnitude;

        long currentTime = System.currentTimeMillis();

        // 检测峰值：超过阈值且与上一步有足够间隔
        if (delta > STEP_THRESHOLD &&
                currentTime - lastStepTime > STEP_INTERVAL &&
                !isPeakDetected) {

            isPeakDetected = true;
            stepCount++;
            lastStepTime = currentTime;

            // 通知步数变化
            if (stepListener != null) {
                stepListener.onStepChanged(stepCount);
            }
            Log.d(TAG, "检测到步数，当前总步数：" + stepCount);
        }
        // 重置峰值检测状态
        else if (delta < STEP_THRESHOLD / 2) {
            isPeakDetected = false;
        }
    }

    // 获取当前步数
    public int getStepCount() {
        return stepCount;
    }

    // 重置步数
    public void resetSteps() {
        stepCount = 0;
        if (stepListener != null) {
            stepListener.onStepChanged(stepCount);
        }
    }

    // 设置步数变化监听器
    public void setOnStepChangeListener(OnStepChangeListener listener) {
        this.stepListener = listener;
    }

    // 步数变化回调接口
    public interface OnStepChangeListener {
        void onStepChanged(int totalSteps);
    }
}