package com.example.can301_cw1_test.ui;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.LocationManager;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.service.PerceptionService;
import com.example.can301_cw1_test.service.background.BatteryOptHelper;
import com.example.can301_cw1_test.service.location.LocationService;
import com.example.can301_cw1_test.util.PermissionUtil;

public class MainActivity extends AppCompatActivity {
    private ToggleButton btnToggle;

    private Button btnAiDiary, btnSchedule, btnViewHistory, btnResetSteps;
    private TextView tvGpsStatus, tvSensorStatus, tvStepCount;

    private LocationService locationService;
    private PerceptionService perceptionService;
    private boolean isServiceRunning = false;
    private boolean isServiceBound = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable statusChecker;

    // 权限请求码
    private static final int SENSOR_PERMISSION_REQUEST = 100;

    private static final int LOCATION_PERMISSION_REQUEST = 1001;
    private static final int BACKGROUND_LOCATION_REQUEST = 1002;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1003;

    // 服务连接
    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            perceptionService = ((PerceptionService.LocalBinder) service).getService();
            isServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isServiceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 视图初始化
        btnToggle = findViewById(R.id.btn_toggle);
        btnAiDiary = findViewById(R.id.btnAiDiary);
        btnSchedule = findViewById(R.id.btn_schedule);
        btnViewHistory = findViewById(R.id.btn_view_history);
        tvGpsStatus = findViewById(R.id.tv_gps_status);
        tvSensorStatus = findViewById(R.id.tv_sensor_status);
        tvStepCount = findViewById(R.id.tv_step_count);
        btnResetSteps = findViewById(R.id.btn_reset_steps);

        // 绑定服务
        locationService = new LocationService(this);
        bindService(new Intent(this, PerceptionService.class),
                serviceConnection, Context.BIND_AUTO_CREATE);

        btnToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) { // 启动
                checkGpsEnabled();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                        && !PermissionUtil.checkNotificationPermission(this)) {
                    PermissionUtil.requestNotificationPermission(this, NOTIFICATION_PERMISSION_REQUEST);
                    btnToggle.setChecked(false); // 权限通过后再 true
                    return;
                }
                checkAndRequestLocationPermissions();
                changeToggleButtonColor("#FF0000"); // 红色
                btnToggle.setText("停止");
            } else { // 停止
                stopPerceptionService();
                changeToggleButtonColor("#3F72AF"); // 恢复初始颜色
                btnToggle.setText("启动");
            }
        });

        btnResetSteps.setOnClickListener(v -> resetStepCount());
        btnAiDiary.setOnClickListener(v -> startActivity(new Intent(this, AiDiaryActivity.class)));
        btnViewHistory.setOnClickListener(v -> startActivity(new Intent(this, BehaviorHistoryActivity.class)));
        btnSchedule.setOnClickListener(v -> startActivity(new Intent(this, ScheduleInputActivity.class)));

        statusChecker = () -> {
            updateStatusDisplay();
            updateStepCount();
            handler.postDelayed(statusChecker, 1000);
        };
    }

    private void changeToggleButtonColor(String color) {
        GradientDrawable background = (GradientDrawable) btnToggle.getBackground();
        background.setColor(Color.parseColor(color));
    }

    private void startPerceptionService() {
        if (!PermissionUtil.checkLocationPermissions(this)) {
            checkAndRequestLocationPermissions();
            return;
        }
        Intent intent = new Intent(this, PerceptionService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(intent);
        else
            startService(intent);
        isServiceRunning = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            BatteryOptHelper.requestIgnoreBatteryOptimizations(this);
        updateStatusDisplay();
        Toast.makeText(this, "服务已启动", Toast.LENGTH_SHORT).show();
    }

    private void stopPerceptionService() {
        stopService(new Intent(this, PerceptionService.class));
        isServiceRunning = false;
        updateStatusDisplay();
        Toast.makeText(this, "服务已停止", Toast.LENGTH_SHORT).show();
    }

    private void requestSensorPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.BODY_SENSORS},
                    SENSOR_PERMISSION_REQUEST);
        }
    }

    private void resetStepCount() {
        if (isServiceBound && perceptionService != null) {
            perceptionService.resetSteps();
            tvStepCount.setText("当前步数: 0");
            Toast.makeText(this, "步数已重置", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "请先启动服务", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateStatusDisplay() {
        boolean gps = locationService.isLocationAvailable();
        tvGpsStatus.setText(gps ? "GPS/网络定位服务：已启用" : "GPS/网络定位服务：未启用");
        tvSensorStatus.setText(isServiceRunning ? "服务状态：已启动" : "服务状态：未启动");
        btnToggle.setChecked(isServiceRunning);
    }

    private void updateStepCount() {
        if (isServiceBound && perceptionService != null) {
            tvStepCount.setText(String.format("当前步数: %d", perceptionService.getStepCount()));
        } else {
            tvStepCount.setText("当前步数: --");
        }
    }

    private void checkGpsEnabled() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            Toast.makeText(this, "请开启GPS以获取高精度定位", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkAndRequestLocationPermissions() {
        if (!PermissionUtil.checkLocationPermissions(this)) {
            PermissionUtil.requestLocationPermissions(this, LOCATION_PERMISSION_REQUEST);
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    && !PermissionUtil.hasBackgroundLocationPermission(this)) {
                PermissionUtil.requestBackgroundLocationPermission(this, BACKGROUND_LOCATION_REQUEST);
            } else {
                startPerceptionService();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (PermissionUtil.verifyPermissions(grantResults)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        && !PermissionUtil.hasBackgroundLocationPermission(this)) {
                    PermissionUtil.requestBackgroundLocationPermission(this, BACKGROUND_LOCATION_REQUEST);
                } else {
                    startPerceptionService();
                }
            } else {
                Toast.makeText(this, "定位权限不足，无法启动服务", Toast.LENGTH_SHORT).show();
                btnToggle.setChecked(false);
            }
        } else if (requestCode == BACKGROUND_LOCATION_REQUEST) {
            if (PermissionUtil.verifyPermissions(grantResults)) {
                startPerceptionService();
            } else {
                Toast.makeText(this, "需要后台定位权限才能正常运行", Toast.LENGTH_SHORT).show();
                btnToggle.setChecked(false);
            }
        } else if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            if (PermissionUtil.verifyPermissions(grantResults)) {
                checkAndRequestLocationPermissions();
            } else {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                Toast.makeText(this, "请手动开启“通知”权限，否则无法显示前台状态", Toast.LENGTH_LONG).show();
                btnToggle.setChecked(false);
            }
        }else if (requestCode == SENSOR_PERMISSION_REQUEST) { // 新增：处理传感器权限结果
            if (PermissionUtil.verifyPermissions(grantResults)) {
                // 传感器权限授予，启动服务（如果toggle是开启状态）
                if (btnToggle.isChecked()) {
                    startPerceptionService();
                }
            } else {
                // 传感器权限被拒绝，提示并关闭toggle
                Toast.makeText(this, "缺少传感器权限，计步功能无法使用", Toast.LENGTH_SHORT).show();
                btnToggle.setChecked(false);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusChecker);
        checkGpsEnabled();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusChecker);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(statusChecker);
        if (isServiceBound) {
            unbindService(serviceConnection);
            isServiceBound = false;
        }
    }
}