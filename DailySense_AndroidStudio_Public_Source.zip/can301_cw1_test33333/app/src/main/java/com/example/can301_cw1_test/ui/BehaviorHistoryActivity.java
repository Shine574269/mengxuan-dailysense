package com.example.can301_cw1_test.ui;

import android.view.View;
import android.widget.AdapterView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import android.content.Intent;

import com.example.can301_cw1_test.model.Behavior;
import com.example.can301_cw1_test.service.BehaviorDbHelper;
import com.example.can301_cw1_test.ui.adapter.BehaviorAdapter;

import com.example.can301_cw1_test.R;

public class BehaviorHistoryActivity extends AppCompatActivity {
    private ListView behaviorListView;
    private BehaviorDbHelper dbHelper;
    private BehaviorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_behavior_history);

        behaviorListView = findViewById(R.id.lv_behavior_history);
        dbHelper = new BehaviorDbHelper(this);

        // 异步查询数据库（Android 11+ AsyncTask已过时，可替换为Handler，见下文备注）
        // 加载历史数据
        new QueryBehaviorsTask().execute();
    }

    // 异步查询任务
    private class QueryBehaviorsTask extends AsyncTask<Void, Void, List<Behavior>> {
        @Override
        protected List<Behavior> doInBackground(Void... voids) {
            return dbHelper.queryAll(); // 调用数据库查询方法
        }

        @Override
        protected void onPostExecute(List<Behavior> behaviors) {
            super.onPostExecute(behaviors);
            // 设置适配器，支持时间戳点击
            adapter = new BehaviorAdapter(BehaviorHistoryActivity.this, behaviors,
                    (view, behavior) -> {
                        // 跳转到标签编辑页面
                        Intent intent = new Intent(BehaviorHistoryActivity.this, TagEditActivity.class);
                        intent.putExtra("behavior_id", behavior.getId());
                        startActivity(intent);
                    });
            behaviorListView.setAdapter(adapter);

            // 添加长按删除功能
            behaviorListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    Behavior behavior = (Behavior) parent.getItemAtPosition(position);
                    showDeleteConfirmationDialog(behavior, position);
                    return true;
                }
            });
        }
    }

    // 添加删除确认对话框
    private void showDeleteConfirmationDialog(Behavior behavior, int position) {
        new AlertDialog.Builder(this)
                .setTitle("删除记录")
                .setMessage("确定要删除这条记录吗？")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 执行删除操作
                        new DeleteBehaviorTask().execute(behavior.getId(), position);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // 添加删除记录的异步任务
    private class DeleteBehaviorTask extends AsyncTask<Object, Void, Integer> {
        @Override
        protected Integer doInBackground(Object... params) {
            try {
                int behaviorId = (int) params[0];
                int position = (int) params[1];
                // 创建独立的dbHelper实例，避免依赖Activity的dbHelper
                BehaviorDbHelper taskDbHelper = new BehaviorDbHelper(BehaviorHistoryActivity.this);
                int rowsDeleted = taskDbHelper.delete(behaviorId);
                taskDbHelper.close(); // 单独关闭
                return rowsDeleted > 0 ? position : -1;
            } catch (Exception e) {
                e.printStackTrace();
                return -1;
            }
        }

        @Override
        protected void onPostExecute(Integer position) {
            if (position != -1) {
                adapter.remove(position);
                Toast.makeText(BehaviorHistoryActivity.this, "记录已删除", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(BehaviorHistoryActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close(); // 关闭数据库
        }
    }
}
