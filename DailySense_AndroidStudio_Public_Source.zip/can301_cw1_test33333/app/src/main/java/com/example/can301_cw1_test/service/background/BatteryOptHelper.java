package com.example.can301_cw1_test.service.background;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.widget.Toast;

import android.provider.Settings;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;

/**
 * 电池白名单申请
 */
public class BatteryOptHelper {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void requestIgnoreBatteryOptimizations(Activity activity) {
        PowerManager pm = (PowerManager) activity.getSystemService(activity.POWER_SERVICE);
        if (!pm.isIgnoringBatteryOptimizations(activity.getPackageName())) {
            new AlertDialog.Builder(activity)
                    .setTitle("需要后台运行权限")
                    .setMessage("为确保应用在后台正常跟踪位置和记录行为，请允许应用忽略电池优化。")
                    .setPositiveButton("去设置", (dialog, which) -> {
                        Intent intent = new Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + activity.getPackageName())
                        );
                        // 移除不必要的FLAG_ACTIVITY_NEW_TASK
                        try {
                            activity.startActivity(intent);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(activity, "无法打开设置，请手动前往电池优化中允许本应用", Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    })
                    .setNegativeButton("取消", (dialog, which) -> {
                        Toast.makeText(activity, "后台功能可能受限", Toast.LENGTH_SHORT).show();
                    })
                    .show();
        }
    }
}