package com.example.can301_cw1_test.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.database.DBHelper;
import com.example.can301_cw1_test.model.Schedule;
import com.example.can301_cw1_test.ui.adapter.ScheduleAdapter;
import com.example.can301_cw1_test.util.CircularProgressView;

import java.text.SimpleDateFormat;
import java.util.*;

public class ScheduleInputActivity extends AppCompatActivity implements ScheduleAdapter.OnScheduleUpdateListener {

    private TextView tvCurrentDate, tvTotalCount;
    private LinearLayout dateContainer;
    private RecyclerView rvSchedules;
    private EditText etTitle, etTarget;
    private ImageButton btnBack, btnAdd;
    private CircularProgressView progressCircle;

    private ScheduleAdapter scheduleAdapter;
    private List<Schedule> scheduleList;
    private DBHelper dbHelper;

    private SimpleDateFormat displayDateFormat;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_input);

        initViews();
        initData();
        setupDateSelector();
        loadSchedulesForDate(selectedDate);
        updateStatistics();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btn_back);
        tvCurrentDate = findViewById(R.id.tv_current_date);
        tvTotalCount = findViewById(R.id.tv_total_count);
        dateContainer = findViewById(R.id.date_container);
        rvSchedules = findViewById(R.id.rv_schedules);
        etTitle = findViewById(R.id.et_title);
        etTarget = findViewById(R.id.et_target);
        btnAdd = findViewById(R.id.btn_add);
        progressCircle = findViewById(R.id.progress_circle);

        dbHelper = new DBHelper(this);
        displayDateFormat = new SimpleDateFormat("MMMM d, yyyy EEEE", Locale.ENGLISH);

        selectedDate = getCurrentDateString();

        scheduleList = new ArrayList<>();
        scheduleAdapter = new ScheduleAdapter(scheduleList);
        scheduleAdapter.setDbHelper(dbHelper);
        scheduleAdapter.setOnScheduleUpdateListener(this);

        rvSchedules.setLayoutManager(new LinearLayoutManager(this));
        rvSchedules.setAdapter(scheduleAdapter);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnAdd.setOnClickListener(v -> addNewSchedule());

        updateCurrentDateDisplay();
    }

    private void initData() {
        // 初始化数据
    }

    private void setupDateSelector() {
        dateContainer.removeAllViews();

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -3);

        for (int i = 0; i < 7; i++) {
            View dateItem = LayoutInflater.from(this).inflate(R.layout.item_date, dateContainer, false);
            TextView tvDate = dateItem.findViewById(R.id.tv_date);
            TextView tvWeek = dateItem.findViewById(R.id.tv_week);

            String dateStr = formatDate(calendar);
            String dayStr = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
            String weekStr = getWeekStringEnglish(calendar);

            tvDate.setText(dayStr);
            tvWeek.setText(weekStr);

            // Set selected status
            if (dateStr.equals(selectedDate)) {
                dateItem.setBackgroundResource(R.drawable.date_item_selected_bg);
                tvDate.setTextColor(getColor(R.color.orange));
                tvWeek.setTextColor(getColor(R.color.orange));
            } else {
                dateItem.setBackgroundResource(R.drawable.date_item_bg);
                tvDate.setTextColor(getColor(android.R.color.black));
                tvWeek.setTextColor(getColor(android.R.color.darker_gray));
            }

            final String finalDateStr = dateStr;
            dateItem.setOnClickListener(v -> {
                selectedDate = finalDateStr;
                setupDateSelector(); // Refresh date selector
                loadSchedulesForDate(selectedDate);
                updateCurrentDateDisplay();
            });

            dateContainer.addView(dateItem);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }
    }

    private void loadSchedulesForDate(String date) {
        scheduleList.clear();
        scheduleList.addAll(dbHelper.getSchedulesByDate(date));
        scheduleAdapter.updateData(scheduleList);
        updateStatistics();
    }

    private void updateStatistics() {
        int total = scheduleList.size();
        int completed = 0;
        for (Schedule schedule : scheduleList) {
            if (schedule.isCompleted()) {
                completed++;
            }
        }

        tvTotalCount.setText(completed + " of " + total + " completed");

        // Update progress circle
        float progress = total > 0 ? (float) completed / total * 100 : 0;
        progressCircle.setProgress(progress);
    }

    private void addNewSchedule() {
        String title = etTitle.getText().toString().trim();
        String target = etTarget.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, "Please input schedule title", Toast.LENGTH_SHORT).show();
            return;
        }

        Schedule schedule = new Schedule();
        schedule.setTitle(title);
        schedule.setTarget(target);
        schedule.setDate(selectedDate);
        schedule.setCompleted(false);
        schedule.setCreatedTime(System.currentTimeMillis());

        long id = dbHelper.addSchedule(schedule);
        if (id != -1) {
            etTitle.setText("");
            etTarget.setText("");
            loadSchedulesForDate(selectedDate);
            Toast.makeText(this, "Added successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to add", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateCurrentDateDisplay() {
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(selectedDate);
            if (date != null) {
                String displayDate = displayDateFormat.format(date);
                tvCurrentDate.setText(displayDate);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String formatDate(Calendar calendar) {
        return String.format(Locale.ENGLISH, "%04d-%02d-%02d",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH));
    }

    private String getWeekStringEnglish(Calendar calendar) {
        String[] weeks = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        int week = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        return weeks[week];
    }

    private String getCurrentDateString() {
        Calendar cal = Calendar.getInstance();
        return formatDate(cal);
    }

    @Override
    public void onScheduleUpdated() {
        updateStatistics();
    }
}