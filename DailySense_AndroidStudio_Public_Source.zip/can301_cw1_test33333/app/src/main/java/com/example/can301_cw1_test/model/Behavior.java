package com.example.can301_cw1_test.model;


/**
 * 行为记录实体类：存储状态、时间戳等数据
 */
public class Behavior {
    private int id; // 主键（自增）
    private String type; // 状态类型："STILL"或"MOVING"
    private long startTime; // 开始时间戳（毫秒）
    private Long endTime; // 结束时间戳（可为null，表示状态持续中）
    private String tag; // 用户标签（可为null）
    private double latitude; // 纬度
    private double longitude; // 经度

    // 构造方法：创建新状态时需传入类型、开始时间和经纬度
    public Behavior(String type, long startTime, double latitude, double longitude) {
        this.type = type;
        this.startTime = startTime;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // 构造方法重载：简化版构造方法，只传入核心状态和时间（经纬度默认0），在 SensorService中被使用
    public Behavior(String type, long startTime) {
        this.type = type;
        this.startTime = startTime;
        this.latitude = 0;
        this.longitude = 0;
    }

    public Behavior(){}

    // Getter和Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type){this.type = type;}

    public long getStartTime() { return startTime; }
    public void setStartTime(Long startTime){this.startTime = startTime;}

    public Long getEndTime() { return endTime; }
    public void setEndTime(Long endTime) { this.endTime = endTime; }

    public String getTag() { return tag; }
    public void setTag(String tag) { this.tag = tag; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
}
