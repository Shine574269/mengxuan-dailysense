package com.example.can301_cw1_test.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.ui.MainActivity;

/**
 * 前台通知工具（仅保留此类代码，删除所有PerceptionService相关内容）
 */
public class ServiceNotificationHelper {

    public static final String CHANNEL_ID = "perception_service";
    public static final int NOTIFICATION_ID = 1001;

    /**
     * 首次创建并返回 Notification 对象（供 startForeground 使用）
     */
    public static Notification create(Context context, String content) {
        createChannelIfNeeded(context);

        Intent backIntent = new Intent(context, MainActivity.class);
        android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                context, 0, backIntent, android.app.PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("后台感知运行中")
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pendingIntent)
                .build();
    }

    /**
     * 动态更新通知文字（任意线程调用）
     */
    public static void update(Context context, String newText) {
        Notification notification = create(context, newText);
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification);
    }

    /* 创建渠道（8.0+） */
    private static void createChannelIfNeeded(Context context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "后台感知",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("实时显示后台感知服务运行状态");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
}
