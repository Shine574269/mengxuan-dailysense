package com.example.can301_cw1_test.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.database.DBHelper;
import com.example.can301_cw1_test.model.Schedule;
import com.example.can301_cw1_test.util.CircularProgressView;

import java.util.List;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {

    private List<Schedule> schedules;
    private DBHelper dbHelper;
    private OnScheduleUpdateListener listener;

    public ScheduleAdapter(List<Schedule> schedules) {
        this.schedules = schedules;
    }

    public void setDbHelper(DBHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public void setOnScheduleUpdateListener(OnScheduleUpdateListener listener) {
        this.listener = listener;
    }

    public void updateData(List<Schedule> newSchedules) {
        this.schedules = newSchedules;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_schedule, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Schedule schedule = schedules.get(position);
        holder.bind(schedule);
    }

    @Override
    public int getItemCount() {
        return schedules.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircularProgressView progressCircle;
        TextView tvTitle, tvTarget;
        ImageButton btnStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            progressCircle = itemView.findViewById(R.id.progress_circle);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvTarget = itemView.findViewById(R.id.tv_target);
            btnStatus = itemView.findViewById(R.id.btn_status);
        }

        public void bind(Schedule schedule) {
            tvTitle.setText(schedule.getTitle());
            tvTarget.setText(schedule.getTarget() != null ? "0/" + schedule.getTarget() : "");

            progressCircle.setProgress(schedule.isCompleted() ? 100 : 0);

            btnStatus.setImageResource(schedule.isCompleted() ?
                    R.drawable.ic_check : R.drawable.ic_add);

            btnStatus.setOnClickListener(v -> {
                if (dbHelper != null) {
                    schedule.setCompleted(!schedule.isCompleted());
                    int rowsAffected = dbHelper.updateSchedule(schedule);

                    if (rowsAffected > 0) {
                        // update UI
                        progressCircle.setProgress(schedule.isCompleted() ? 100 : 0);
                        btnStatus.setImageResource(schedule.isCompleted() ?
                                R.drawable.ic_check : R.drawable.ic_add);

                        // Notify listeners
                        if (listener != null) {
                            listener.onScheduleUpdated();
                        }
                    } else {
                        Toast.makeText(itemView.getContext(), "Update failed", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // 长按删除功能（可选）
            itemView.setOnLongClickListener(v -> {
                if (dbHelper != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Schedule scheduleToDelete = schedules.get(position);
                        int rowsDeleted = dbHelper.deleteSchedule(scheduleToDelete.getId());

                        if (rowsDeleted > 0) {
                            schedules.remove(position);
                            notifyItemRemoved(position);

                            if (listener != null) {
                                listener.onScheduleUpdated();
                            }

                            Toast.makeText(itemView.getContext(), "Schedule deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(itemView.getContext(), "Delete failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                return true;
            });
        }
    }

    public interface OnScheduleUpdateListener {
        void onScheduleUpdated();
    }
}