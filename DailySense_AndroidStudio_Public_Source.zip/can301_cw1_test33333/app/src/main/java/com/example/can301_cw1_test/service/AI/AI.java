// service/ai/AI.java
package com.example.can301_cw1_test.service.AI;

import com.example.can301_cw1_test.database.DBHelper;
import com.example.can301_cw1_test.model.Schedule;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.util.Log;

import com.example.can301_cw1_test.model.AIRequest;

import com.example.can301_cw1_test.model.AIResponse;
import com.example.can301_cw1_test.model.Behavior;
import com.example.can301_cw1_test.service.BehaviorDbHelper; // 导入数据库助手
import com.example.can301_cw1_test.util.ApiUtil;
import com.example.can301_cw1_test.util.TimeUtil; // 导入时间工具类

import com.example.can301_cw1_test.service.AI.AIResponseParser;
import java.util.List;

public class AI {
    private static final String TAG = "AI_Manager";

    private final Context context;
    private final BehaviorDbHelper behaviorDbHelper; // 数据库助手实例

    private final DBHelper dbHelper;

    // 回调接口
    public interface DiaryGenerationCallback {
        void onSuccess(String generatedDiaryText);
        void onFailure(String errorMessage);
    }

    // 构造器：初始化数据库助手
    public AI(Context context) {
        this.context = context.getApplicationContext();
        this.behaviorDbHelper = new BehaviorDbHelper(this.context); // 关键：实例化数据库助手
        this.dbHelper = new DBHelper(this.context); // 初始化日程数据库助手
    }


    // 添加获取今日日程的方法
    private List<Schedule> getTodaySchedules() {
        try {
            // 获取今日日期字符串（与Schedule表中date格式保持一致，假设为"yyyy-MM-dd"）
            String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    .format(new Date());
            // 调用DBHelper查询今日日程
            return dbHelper.getSchedulesByDate(todayDate);
        } catch (Exception e) {
            Log.e(TAG, "获取今日日程失败: " + e.getMessage(), e);
            return new java.util.ArrayList<>();
        }
    }

    /**
     * 主要方法：根据行为列表生成日记
     */
    public void generateDiaryFromBehaviors(List<Behavior> behaviors,
                                           String userMood,
                                           DiaryGenerationCallback callback) {

        if (behaviors == null || behaviors.isEmpty()) {
            callback.onFailure("没有可用的行为数据");
            return;
        }

        // 1. 创建请求对象
        AIRequest request = new AIRequest(behaviors, userMood);

        Log.d(TAG, String.format("开始生成日记: tag=%s, 时间段=%d-%d, 数据量=%d",
                request.getBehaviorTag(),
                request.getStartTime(),
                request.getEndTime(),
                behaviors.size()));

        // 2. 调用ApiUtil
        ApiUtil.callAiDiaryApi(
                request.getBehaviorTag(),
                request.getStartTime(),
                request.getEndTime(),
                behaviors, // 新增：传递行为列表
                new ApiUtil.AiResponseCallback() {

                    // 在AI.generateDiaryFromBehaviors的onSuccess回调中修改
                    @Override
                    public void onSuccess(String result) {
                        // 3. 解析响应
                        AIResponse aiResponse = AIResponseParser.parse(result);

                        if (aiResponse.isSuccess()) {
                            // 生成日记文本并拼接日程提醒
                            String diaryText = aiResponse.getGeneratedText() + generateScheduleReminder();
                            callback.onSuccess(diaryText);
                            Log.i(TAG, "日记生成成功");
                        } else {
                            Log.w(TAG, "AI服务返回错误: " + aiResponse.getErrorMessage());
                            String fallbackText = AIResponseParser.generateFallbackDiary(
                                    request.getBehaviorTag(),
                                    request.getStartTime(),
                                    request.getEndTime()
                            ) + generateScheduleReminder(); //  fallback文本也添加提醒
                            callback.onSuccess(fallbackText);
                        }
                    }


                    @Override
                    public void onFailure(String error) {
                        Log.e(TAG, "AI API调用失败: " + error);
                        String fallbackText = AIResponseParser.generateFallbackDiary(
                                request.getBehaviorTag(),
                                request.getStartTime(),
                                request.getEndTime()
                        ) + generateScheduleReminder(); // 失败时的 fallback 也添加提醒
                        callback.onSuccess(fallbackText);
                    }
                }
        );
    }

    /**
     * 便捷方法：为今天的所有行为生成日记
     */
    public void generateDiaryForToday(String userMood, DiaryGenerationCallback callback) {
        List<Behavior> todayBehaviors = getTodayBehaviorsFromDb();
        generateDiaryFromBehaviors(todayBehaviors, userMood, callback);
    }

    /**
     * 从数据库获取今天的行为记录（核心修复）
     */
    private List<Behavior> getTodayBehaviorsFromDb() {
        try {
            // 1. 获取今日00:00:00的时间戳
            long todayStart = TimeUtil.getTodayStartTime();
            // 2. 获取当前时间戳
            long now = System.currentTimeMillis();
            // 3. 调用BehaviorDbHelper查询今日数据
            List<Behavior> behaviors = behaviorDbHelper.getBehaviorsByTimeRange(todayStart, now);
            Log.d(TAG, "查询到今日行为数据：" + behaviors.size() + "条");
            return behaviors;
        } catch (Exception e) {
            Log.e(TAG, "获取今日行为数据失败: " + e.getMessage(), e);
            return new java.util.ArrayList<>();
        }
    }

    /**
     * 为特定时间段生成日记
     */
    public void generateDiaryForPeriod(long startTime, long endTime,
                                       String userMood, DiaryGenerationCallback callback) {
        List<Behavior> periodBehaviors = getBehaviorsFromDb(startTime, endTime);
        generateDiaryFromBehaviors(periodBehaviors, userMood, callback);
    }

    /**
     * 生成日程提醒和建议文本
     */
    private String generateScheduleReminder() {
        List<Schedule> todaySchedules = getTodaySchedules();
        if (todaySchedules.isEmpty()) {
            return "\n\n今日没有安排日程，建议明天可以规划一些任务哦~";
        }

        // 分离已完成和未完成的日程
        List<Schedule> completed = new java.util.ArrayList<>();
        List<Schedule> uncompleted = new java.util.ArrayList<>();
        for (Schedule schedule : todaySchedules) {
            if (schedule.isCompleted()) {
                completed.add(schedule);
            } else {
                uncompleted.add(schedule);
            }
        }

        // 构建提醒文本
        StringBuilder reminder = new StringBuilder("\n\n【日程提醒与建议】");

        // 未完成事项提醒
        if (!uncompleted.isEmpty()) {
            reminder.append("\n今日未完成的任务：");
            for (int i = 0; i < uncompleted.size(); i++) {
                reminder.append("\n").append(i + 1).append(". ").append(uncompleted.get(i).getTitle());
            }
            reminder.append("\n建议：明天可以优先完成这些未完成的任务，避免堆积哦~");
        }

        // 已完成事项鼓励
        if (!completed.isEmpty()) {
            reminder.append("\n\n今日已完成的任务：");
            for (int i = 0; i < completed.size(); i++) {
                reminder.append("\n").append(i + 1).append(". ").append(completed.get(i).getTitle());
            }
            reminder.append("\n真棒！已完成的任务可以总结经验，明天继续保持高效哦~");
        }

        return reminder.toString();
    }

    /**
     * 查询指定时间段的行为数据（核心修复）
     */
    private List<Behavior> getBehaviorsFromDb(long startTime, long endTime) {
        try {
            // 调用BehaviorDbHelper查询指定时间范围的数据
            List<Behavior> behaviors = behaviorDbHelper.getBehaviorsByTimeRange(startTime, endTime);
            Log.d(TAG, String.format("查询到[%d-%d]时间段行为数据：%d条",
                    startTime, endTime, behaviors.size()));
            return behaviors;
        } catch (Exception e) {
            Log.e(TAG, "获取指定时间段行为数据失败: " + e.getMessage(), e);
            return new java.util.ArrayList<>();
        }
    }
}