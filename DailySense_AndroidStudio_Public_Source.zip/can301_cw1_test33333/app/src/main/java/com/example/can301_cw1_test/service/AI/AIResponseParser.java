// service/ai/AIResponseParser.java
package com.example.can301_cw1_test.service.AI;

import android.util.Log;

import com.example.can301_cw1_test.model.AIResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

public class AIResponseParser {
    private static final String TAG = "AIResponseParser";

    /**
     * 解析AI API返回的JSON字符串
     */
    public static AIResponse parse(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return new AIResponse(null, "error", "AI服务返回空响应");
        }



        try {
            JSONObject json = new JSONObject(jsonString);

            // 正确解析DeepSeek/OpenAI格式的响应
            if (json.has("choices") && json.getJSONArray("choices").length() > 0) {
                JSONArray choices = json.getJSONArray("choices");
                JSONObject firstChoice = choices.getJSONObject(0);
                JSONObject message = firstChoice.getJSONObject("message");
                String generatedText = message.optString("content", "").trim();

                if (!generatedText.isEmpty()) {
                    return new AIResponse(generatedText, "success", null);
                } else {
                    return new AIResponse(null, "error", "AI返回空内容");
                }
            } else if (json.has("error")) {
                // 解析API错误信息
                String errorMsg = json.getJSONObject("error").optString("message", "未知错误");
                return new AIResponse(null, "error", errorMsg);
            } else {
                return new AIResponse(null, "error", "响应格式不正确");
            }

        } catch (JSONException e) {
            Log.e(TAG, "JSON解析失败: " + e.getMessage());
            // 纯文本处理（极端情况）
            if (jsonString.toLowerCase().contains("error")) {
                return new AIResponse(null, "error", jsonString);
            } else {
                return new AIResponse(jsonString, "success", null);
            }
        }
    }

    /**
     * 生成后备日记（当AI服务失败时使用）
     */
    public static String generateFallbackDiary(String behaviorTag, long startTime, long endTime) {
        long durationMinutes = (endTime - startTime) / (1000 * 60);

        if (durationMinutes <= 0) {
            durationMinutes = 30; // 默认值
        }

        String[] templates = {
                String.format("在过去的%d分钟里，我主要处于%s状态。这是一个平凡的时间段。",
                        durationMinutes, behaviorTag),
                String.format("记录：%s持续了约%d分钟。生活就是这样，在动静之间流转。",
                        behaviorTag, durationMinutes),
                String.format("今日活动：%s。时间从%s持续到%s。",
                        behaviorTag,
                        formatTime(startTime),
                        formatTime(endTime))
        };

        // 随机选择一个模板
        int index = (int) (System.currentTimeMillis() % templates.length);
        return templates[index];
    }

    private static String formatTime(long timestamp) {
        // 简单的时间格式化
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
        return sdf.format(new java.util.Date(timestamp));
    }
}