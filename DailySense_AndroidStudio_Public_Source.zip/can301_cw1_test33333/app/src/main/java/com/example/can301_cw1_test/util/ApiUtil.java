// util/ApiUtil.java
package com.example.can301_cw1_test.util;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
// 导入Behavior类（包名需和你实际创建的一致）
import com.example.can301_cw1_test.model.Behavior;
public class ApiUtil {
    private static final String TAG = "ApiUtil";

    // DeepSeek API 地址（与OpenAI完全兼容）
    private static final String DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions";

    // ⚠️ 重要：不要硬编码在代码中！应该从安全存储获取
    // 建议方案：1. 放在local.properties 2. 从服务器动态获取 3. 用户输入
    private static final String API_KEY = "REPLACE_WITH_YOUR_OWN_KEY"; // 替换为您的真实密钥

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    public interface AiResponseCallback {
        void onSuccess(String result);
        void onFailure(String error);
    }

    /**
     * 调用 DeepSeek API 生成日记
     */
    public static void callAiDiaryApi(String behaviorTag,
                                      long startTime,
                                      long endTime,
                                      List<Behavior> behaviors,
                                      AiResponseCallback callback) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                // 1. 创建连接
                URL url = new URL(DEEPSEEK_API_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
                conn.setRequestProperty("Accept", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000); // 15秒连接超时
                conn.setReadTimeout(30000);    // 30秒读取超时

                // 2. 构建请求体（OpenAI兼容格式）
                JSONObject requestBody = new JSONObject();
                requestBody.put("model", "deepseek-chat"); // DeepSeek模型
                requestBody.put("temperature", 0.7);       // 创造性
                requestBody.put("max_tokens", 800);        // 最大输出长度
                requestBody.put("stream", false);          // 非流式响应

                // 3. 构建消息数组
                JSONArray messages = new JSONArray();

                // 系统提示词
                JSONObject systemMessage = new JSONObject();
                systemMessage.put("role", "system");
                systemMessage.put("content", buildSystemPrompt());
                messages.put(systemMessage);

                // 用户消息
                JSONObject userMessage = new JSONObject();
                userMessage.put("role", "user");
                userMessage.put("content", buildUserPrompt(behaviorTag,startTime, endTime,behaviors));
                messages.put(userMessage);

                requestBody.put("messages", messages);

                // 4. 发送请求
                String requestJson = requestBody.toString();
                Log.d(TAG, "发送请求到DeepSeek: " + requestJson);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(requestJson.getBytes("UTF-8"));
                    os.flush();
                }

                // 5. 读取响应
                int responseCode = conn.getResponseCode();
                Log.d(TAG, "DeepSeek响应码: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    String responseBody = response.toString();
                    Log.d(TAG, "DeepSeek原始响应: " + responseBody);

                    // 6. 解析响应
                    String diaryText = parseDeepSeekResponse(responseBody);
                    callback.onSuccess(diaryText);

                } else {
                    // 读取错误信息
                    BufferedReader errorReader = new BufferedReader(
                            new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                    StringBuilder errorResponse = new StringBuilder();
                    String errorLine;
                    while ((errorLine = errorReader.readLine()) != null) {
                        errorResponse.append(errorLine);
                    }
                    errorReader.close();

                    String errorMsg = "HTTP " + responseCode + ": " + errorResponse.toString();
                    Log.e(TAG, "DeepSeek API错误: " + errorMsg);
                    callback.onFailure(errorMsg);
                }

            } catch (IOException | JSONException e) {
                Log.e(TAG, "DeepSeek API调用异常", e);
                callback.onFailure("API调用异常: " + e.getMessage());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        });
    }

    /**
     * 构建系统提示词
     */
    private static String buildSystemPrompt() {
        return "你是一个智能日记助手，专门根据用户所有的行为数据生成自然、流畅、有情感的个人日记。\n" +
                "要求：\n" +
                "1. 用第一人称（我）写作\n" +
                "2. 语言自然流畅，像真人日记\n" +
                "3. 适当加入情感和感悟\n" +
                "4. 必须包含：**行为状态（用户提供的核心行为）的细节描述**、时间流逝感受、个人小感悟\n" +  // 新增强调
                "5. 长度在200-400字左右\n" +
                "6. 严格围绕用户提供的行为状态展开想象，不得偏离核心行为\n " +
                "7. 涵盖所有行为记录的细节，按时间顺序描述" ;  // 新增限制
    }

    /**
     * 构建用户提示词
     */
    // 新增参数：List<Behavior> behaviors
    private static String buildUserPrompt(String behaviorTag, long startTime, long endTime,
                                          List<Behavior> behaviors) {
        String startTimeStr = TimeUtil.formatTimestamp(startTime);
        String endTimeStr = TimeUtil.formatTimestamp(endTime);
        long durationMinutes = (endTime - startTime) / (1000 * 60);

        // 构建行为详情字符串
        StringBuilder behaviorDetails = new StringBuilder();
        behaviorDetails.append("具体行为记录：\n");
        for (int i = 0; i < behaviors.size(); i++) {
            Behavior b = behaviors.get(i);
            String bStartTime = TimeUtil.formatTimestamp(b.getStartTime());
            String bEndTime = b.getEndTime() != null ?
                    TimeUtil.formatTimestamp(b.getEndTime()) : "持续中";
            String tag = b.getTag() != null ? b.getTag() : "无标签";

            behaviorDetails.append(String.format(
                    "%d. 类型：%s，开始：%s，结束：%s，标签：%s\n",
                    i + 1, b.getType(), bStartTime, bEndTime, tag
            ));
        }

        // 完整提示词：包含统计标签+具体行为
        return String.format(
                "请根据以下行为数据生成一篇日记：\n" +
                        "行为统计：%s\n" +
                        "开始时间：%s\n" +
                        "结束时间：%s\n" +
                        "持续时间：%d分钟\n" +
                        "%s\n" + // 插入具体行为详情
                        "请生成一篇自然流畅的日记，描述这段时间的经历和感受。",
                behaviorTag, startTimeStr, endTimeStr, durationMinutes, behaviorDetails.toString()
        );
    }

    /**
     * 解析DeepSeek响应
     */
    private static String parseDeepSeekResponse(String responseBody) throws JSONException {
        JSONObject responseJson = new JSONObject(responseBody);

        // 检查是否有错误
        if (responseJson.has("error")) {
            JSONObject error = responseJson.getJSONObject("error");
            throw new JSONException("DeepSeek API错误: " + error.optString("message", "未知错误"));
        }

        // 提取生成的文本
        JSONArray choices = responseJson.getJSONArray("choices");
        if (choices.length() > 0) {
            JSONObject firstChoice = choices.getJSONObject(0);
            JSONObject message = firstChoice.getJSONObject("message");
            String content = message.optString("content", "").trim();

            if (content.isEmpty()) {
                throw new JSONException("API返回空内容");
            }

            // 清理可能的额外格式
            content = content.replaceAll("^【日记】|^日记：|^#+\\s*", "");
            return content;
        }

        throw new JSONException("API返回无效的响应格式");
    }

    /**
     * 测试API连通性（可选）
     */
//        public static void testApiConnection(AiResponseCallback callback) {
//            callAiDiaryApi("测试行为",
//                    System.currentTimeMillis() - 3600000,
//                    System.currentTimeMillis(),
//                    testBehaviorList,
//                    callback);
//        }

    public static void shutdown() {
        executor.shutdown();
    }
}