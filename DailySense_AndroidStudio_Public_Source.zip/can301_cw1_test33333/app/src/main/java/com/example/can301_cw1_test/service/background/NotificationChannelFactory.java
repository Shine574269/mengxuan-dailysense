package com.example.can301_cw1_test.service.background;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

/**
 * 8.0+ 通知渠道创建工具
 */
public class NotificationChannelFactory {

    public static void createChannelIfNeeded(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "perception_channel",      // 与 PerceptionService 里 startForeground() 用的 id 一致
                    "后台感知",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = activity.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
}