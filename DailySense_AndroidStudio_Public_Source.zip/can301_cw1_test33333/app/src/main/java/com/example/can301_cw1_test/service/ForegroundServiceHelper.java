package com.example.can301_cw1_test.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.example.can301_cw1_test.R;

/**
 * 前台服务辅助类：用于保障服务在后台稳定运行
 */
public class ForegroundServiceHelper {
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "perception_foreground_channel";
    private static final String CHANNEL_NAME = "行为感知服务";

    /**
     * 创建通知渠道（Android 8.0+ 必需）
     */
    public static void createNotificationChannel(PerceptionService service) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = service.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    /**
     * 构建前台服务通知
     */
    public static Notification buildForegroundNotification(PerceptionService service) {
        return new NotificationCompat.Builder(service, CHANNEL_ID)
                .setContentTitle("行为感知中")
                .setContentText("正在记录您的行为状态")
                .setSmallIcon(R.mipmap.ic_launcher) // 替换为项目实际图标资源
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    /**
     * 启动前台服务
     */
    public static void startForeground(PerceptionService service) {
        createNotificationChannel(service);
        Notification notification = buildForegroundNotification(service);
        service.startForeground(NOTIFICATION_ID, notification);
    }
}
