package com.example.can301_cw1_test.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.can301_cw1_test.model.Schedule;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper{
    private static final String DATABASE_NAME = "GrowthApp.db";
    private static final int DATABASE_VERSION = 1;

    // 表名和列名
    public static final String TABLE_SCHEDULES = "schedules";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_TARGET = "target";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_COMPLETED = "completed";
    public static final String COLUMN_CREATED_TIME = "created_time";

    public static final String TABLE_RECORDS = "records";
    public static final String COLUMN_ACTIVITY = "activity";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_START_TIME = "start_time";
    public static final String COLUMN_END_TIME = "end_time";

    // Create Table SQL
    private static final String CREATE_TABLE_SCHEDULES =
            "CREATE TABLE " + TABLE_SCHEDULES + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_TITLE + " TEXT NOT NULL," +
                    COLUMN_TARGET + " TEXT," +
                    COLUMN_DATE + " TEXT NOT NULL," +
                    COLUMN_COMPLETED + " INTEGER DEFAULT 0," +
                    COLUMN_CREATED_TIME + " INTEGER" +
                    ")";
    private static final String CREATE_TABLE_RECORDS =
            "CREATE TABLE " + TABLE_RECORDS + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_ACTIVITY + " TEXT," +
                    COLUMN_LOCATION + " TEXT," +
                    COLUMN_TYPE + " TEXT," +
                    COLUMN_START_TIME + " TEXT," +
                    COLUMN_END_TIME + " TEXT," +
                    COLUMN_DATE + " TEXT" +
                    ")";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SCHEDULES);
        db.execSQL(CREATE_TABLE_RECORDS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULES);
        onCreate(db);
    }

    // add schedule
    public long addSchedule(Schedule schedule) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, schedule.getTitle());
        values.put(COLUMN_TARGET, schedule.getTarget());
        values.put(COLUMN_DATE, schedule.getDate());
        values.put(COLUMN_COMPLETED, schedule.isCompleted() ? 1 : 0);
        values.put(COLUMN_CREATED_TIME, schedule.getCreatedTime());

        long id = db.insert(TABLE_SCHEDULES, null, values);
        db.close();
        return id;
    }

    // query schedule by date
    public List<Schedule> getSchedulesByDate(String date) {
        List<Schedule> schedules = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                COLUMN_ID,
                COLUMN_TITLE,
                COLUMN_TARGET,
                COLUMN_DATE,
                COLUMN_COMPLETED,
                COLUMN_CREATED_TIME
        };

        String selection = COLUMN_DATE + " = ?";
        String[] selectionArgs = {date};
        String orderBy = COLUMN_CREATED_TIME + " ASC";

        Cursor cursor = db.query(
                TABLE_SCHEDULES,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                orderBy
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Schedule schedule = new Schedule();
                schedule.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                schedule.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                schedule.setTarget(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TARGET)));
                schedule.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
                schedule.setCompleted(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_COMPLETED)) == 1);
                schedule.setCreatedTime(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_CREATED_TIME)));

                schedules.add(schedule);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return schedules;
    }

    // update schedule
    public int updateSchedule(Schedule schedule) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, schedule.getTitle());
        values.put(COLUMN_TARGET, schedule.getTarget());
        values.put(COLUMN_DATE, schedule.getDate());
        values.put(COLUMN_COMPLETED, schedule.isCompleted() ? 1 : 0);
        values.put(COLUMN_CREATED_TIME, schedule.getCreatedTime());

        String whereClause = COLUMN_ID + " = ?";
        String[] whereArgs = {String.valueOf(schedule.getId())};

        int rowsAffected = db.update(TABLE_SCHEDULES, values, whereClause, whereArgs);
        db.close();
        return rowsAffected;
    }

    // delete schedule
    public int deleteSchedule(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_ID + " = ?";
        String[] whereArgs = {String.valueOf(id)};

        int rowsAffected = db.delete(TABLE_SCHEDULES, whereClause, whereArgs);
        db.close();
        return rowsAffected;
    }

    public int updateRecordWithMotionData(int recordId, String endTime, int steps, float distance) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_END_TIME, endTime);
        values.put(COLUMN_ACTIVITY, steps + " steps " + distance + " km total distance");

        int rowsAffected = db.update(TABLE_RECORDS, values,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(recordId)});
        db.close();
        return rowsAffected;
    }

    public int updateRecordEndTime(int recordId, String endTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_END_TIME, endTime);

        int rowsAffected = db.update(TABLE_RECORDS, values,
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(recordId)});
        db.close();
        return rowsAffected;
    }

    public int getMotionHoursInCurrentMonth(String currentYearMonth) {
        SQLiteDatabase db = this.getReadableDatabase();
        float totalHours = 0;
        String query = "SELECT " + COLUMN_START_TIME + ", " + COLUMN_END_TIME +
                " FROM " + TABLE_RECORDS +
                " WHERE " + COLUMN_TYPE + " = ?" +
                " AND " + COLUMN_DATE + " LIKE ?";

        String[] selectionArgs = {"Motion", currentYearMonth + "%"};

        Cursor cursor = db.rawQuery(query, selectionArgs);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String startTime = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_START_TIME));
                String endTime = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_END_TIME));
                float hours = calculateTimeDifferenceInHours(startTime, endTime);
                totalHours += hours;

            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return (int) (totalHours / 4);
    }

    // Calculate the small time difference between two time strings
    private float calculateTimeDifferenceInHours(String startTime, String endTime) {
        try {
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());

            java.util.Date startDate = format.parse(startTime);
            java.util.Date endDate = format.parse(endTime);

            if (startDate != null && endDate != null) {
                long difference = endDate.getTime() - startDate.getTime();
                return difference / (1000.0f * 60 * 60);
            }
        } catch (java.text.ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
}