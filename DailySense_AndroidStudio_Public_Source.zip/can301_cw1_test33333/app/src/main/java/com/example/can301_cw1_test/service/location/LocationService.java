package com.example.can301_cw1_test.service.location;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import com.example.can301_cw1_test.util.PermissionUtil;

/**
使用 Android系统的 LocationManager
 **/
public class LocationService {
    private static final String TAG = "LocationService";
    // 定位更新参数
    private static final long MIN_TIME_BW_UPDATES = 60000; // 60秒更新一次
    private static final float MIN_DISTANCE_CHANGE = 0; // 忽略距离变化，仅按时间更新
    // LOCATION_PROVIDERS：string数组，用于定义定位提供者优先级：GPS > 网络
    private static final String[] LOCATION_PROVIDERS = {
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER
    };

    private Context context;
    private LocationManager locationManager;    // Android 系统定位服务的核心管理器，用于注册/移除位置更新、获取定位提供者等
    private LocationListener locationListener;  // 位置监听器，用于接收系统的位置更新回调（如位置变化、提供者禁用等）
    private OnLocationUpdateListener updateListener;    // updateListener变量：指向一个实现了 OnLocationUpdateListener接口的类的对象
                                                        // 将 LocationService 获取到的最新经纬度信息传递给外部组件进行处理
    // 缓存当前最新位置
    private double currentLatitude = 0.0;
    private double currentLongitude = 0.0;

    // 构造器
    public LocationService(Context context) {
        this.context = context;
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        // 调用initLocationListener初始化定位监听器
        initLocationListener();
    }

    // 初始化定位监听器
    private void initLocationListener() {
        // 创建一个实现了 LocationListener接口的匿名内部类，并让变量 locationListener指向一个该匿名内部类的实例
        locationListener = new LocationListener() {
            /*
            重写 LocationListener接口的方法
             */
            // LocationListener接口的 onLocationChanged方法：当设备位置发生变化时触发（运行在主线程）
            // 具体触发条件由 LocationManager.requestLocationUpdates方法的参数决定
            @Override
            public void onLocationChanged(Location location) {
                // 获取到的 Location类实例（即location）不为空的情况下：
                if (location != null) {
                    // 通过Location对象获取经纬度
                    currentLatitude = location.getLatitude();
                    currentLongitude = location.getLongitude();
                    // 打印调试日志
                    Log.d(TAG, "原生定位更新：纬度=" + currentLatitude + "，经度=" + currentLongitude);
                    // 若 updateListener变量指向的实例不为空（该实例应为一个实现了 OnLocationUpdateListener接口的类的实例）：
                    if (updateListener != null) {
                        // 调用该实例的 onLocationUpdated方法（该方法为 OnLocationUpdateListener接口的方法），向外部传递最新经纬度并进行处理
                        // onLocationUpdated方法在 PerceptionService类中被一个匿名内部类实现（updateListener变量指向的实例正是该类的实例），
                        // 具体逻辑为把新获取的经纬度传递给 locationJudge，调用 processLocation方法处理并判断通勤/未移动状态
                        updateListener.onLocationUpdated(currentLatitude, currentLongitude);
                    }
                }
                // 日志输出（便于调试检查）
                Log.d(TAG, "定位更新成功，经纬度：" + location.getLatitude() + "," + location.getLongitude());
            }

            // LocationListener接口的 onStatusChanged方法：当定位提供者（如 GPS、网络）的状态发生变化时回调，例如从 “可用” 变为 “暂时不可用”、信号强度变化等
            // 未具体实现，仅根据规则要求重写
            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            // LocationListener接口的 onProviderEnabled方法：当定位提供者被用户启用时回调（例如用户手动打开 GPS开关或网络定位功能）
            // 也未具体实现
            @Override
            public void onProviderEnabled(String provider) {}

            // LocationListener接口的 onProviderDisabled方法：当定位提供者被用户禁用时回调（例如用户手动关闭 GPS开关或网络定位功能）
            @Override
            public void onProviderDisabled(String provider) {
                Log.w(TAG, "定位提供者 " + provider + " 已禁用，自动切换下一个");
                switchToNextProvider();
            }
        };
    }

    // 启动定位更新（优先用 GPS，失败则切换网络定位）
    public void startLocationUpdates() {
        // 检查定位权限
        if (!PermissionUtil.checkLocationPermissions(context)) {
            Log.e(TAG, "未获取定位权限，无法启动定位");
            return;
        }

        // 尝试启用可用的定位提供者
        boolean isStarted = false;  // isStarted：标记是否成功启动定位提供者；初始为 false
        // 依次遍历数组 LOCATION_PROVIDERS中的每个元素，将元素值赋给 provider
        for (String provider : LOCATION_PROVIDERS) {
            // 调用 LocationManager的 isProviderEnabled方法，传入provider参数，判断当前提供者是否可用
            // locationManager.isProviderEnabled(provider)：
            //  调用 LocationManager的 isProviderEnabled方法，传入provider参数，返回boolean类型结果（true表示该定位提供者可用）
            if (locationManager.isProviderEnabled(provider)) {
                // 若当前定位提供者可用：
                try {
                    // 调用 LocationManager的 requestLocationUpdates方法
                    // provider（String类型）：定位提供者名称；
                    // MIN_TIME_BW_UPDATES（long类型）：最小更新时间间隔；
                    // MIN_DISTANCE_CHANGE（float类型）：最小更新距离；
                    // locationListener（类型为一个实现了 LocationListener接口的类）：定位监听器对象。
                    //  requestLocationUpdates方法：通过指定的定位提供者（如 GPS 或网络定位），按照设定的时间和距离条件，持续监听设备位置变化，并在位置更新时通过 locationListener指向的实例调用 onLocationUpdated方法（该方法为 OnLocationUpdateListener接口的方法），向外部传递最新经纬度，从而实现实时定位功能。
                    //      具体触发条件：
                    //      时间触发：即使设备完全静止，每间隔 60秒 也会触发一次位置更新（获取当前位置）；
                    //      距离触发：忽略；
                    //      两个条件满足任一即可，系统会优先响应 “距离变化”（更贴合 “实时定位” 需求）。
                    locationManager.requestLocationUpdates(
                            provider,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE,
                            locationListener
                    );
                    // 调用 LocationManager的 getLastKnownLocation方法，获取最后已知位置（避免首次定位延迟）
                    Location lastKnown = locationManager.getLastKnownLocation(provider);
                    // 若 lastKnown指向的 Location类对象不为空（即有可用的最后已知位置）：
                    if (lastKnown != null) {
                        // 将经纬度初始化为最后已知位置的经纬度
                        currentLatitude = lastKnown.getLatitude();
                        currentLongitude = lastKnown.getLongitude();
                        updateListener.onLocationUpdated(currentLatitude, currentLongitude);
                    }
                    isStarted = true;   // 标记已成功启动定位提供者
                    Log.d(TAG, "已启动 " + provider + " 定位");
                    break; // 优先启用第一个可用的提供者
                } catch (SecurityException e) {
                    Log.e(TAG, provider + " 定位权限异常：" + e.getMessage());
                }
            }
        }

        // 若 isStarted保持为 false：
        if (!isStarted) {
            Log.e(TAG, "无可用定位提供者（GPS/网络均未开启）");
        }
    }

    // 切换到下一个可用的定位提供者
    // 通过两步操作实现切换：
    // 调用 stopLocationUpdates() 停止当前正在运行的定位更新；
    // 调用 startLocationUpdates() 重新启动定位流程，尝试启用下一个可用的提供者
    private void switchToNextProvider() {
        stopLocationUpdates(); // 先停止当前更新
        startLocationUpdates(); // 重新尝试启动
    }

    // 停止定位更新（释放资源）
    public void stopLocationUpdates() {
        if (locationManager != null && locationListener != null) {
            try {
                locationManager.removeUpdates(locationListener);    // 移除之前注册的 locationListener，终止当前定位提供者的位置更新回调
            } catch (SecurityException e) {
                Log.e(TAG, "停止定位时权限异常：" + e.getMessage());
            }
        }
    }

    // 获取当前缓存的经纬度
    public double getCurrentLatitude() {
        return currentLatitude;
    }

    public double getCurrentLongitude() {
        return currentLongitude;
    }

    // 内部接口 OnLocationUpdateListener：
    // 规定用 onLocationUpdated方法向外部传递新定位（经纬度）
    public interface OnLocationUpdateListener {
        void onLocationUpdated(double latitude, double longitude);
    }

    // 设置状态变化监听器（由外部调用，如 PerceptionService）
    // 接收的参数：一个实现了 OnLocationUpdateListener接口的类的实例
    public void setOnLocationUpdateListener(OnLocationUpdateListener listener) {
        this.updateListener = listener;    // 将实现了 OnLocationUpdateListener接口的类的实例赋值给 LocationService类的成员变量 updateListener
    }

    // 检查定位提供者是否可用
    public boolean isLocationAvailable() {
        // 按优先级依次遍历每个定位提供者，若可用则返回 true
        for (String provider : LOCATION_PROVIDERS) {
            if (locationManager.isProviderEnabled(provider)) {
                return true;
            }
        }
        return false;
    }
}