package com.example.can301_cw1_test.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.can301_cw1_test.R;
import com.example.can301_cw1_test.service.AI.AI;
import com.example.can301_cw1_test.service.BehaviorDbHelper;

public class AiDiaryActivity extends AppCompatActivity {
    private EditText etUserMood;
    private Button btnGenerateToday;
    private Button btnGenerateCustom;
    private Button btnShareDiary;
    private TextView tvDiaryContent;
    private ProgressBar progressBar;
    private BehaviorDbHelper dbHelper;
    private AI aiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_diary);

        initViews();

        dbHelper = new BehaviorDbHelper(this);
        aiManager = new AI(this);
    }

    private void initViews() {
        etUserMood = findViewById(R.id.et_user_mood);
        btnGenerateToday = findViewById(R.id.btn_generate_today);
//        btnGenerateCustom = findViewById(R.id.btn_generate_custom);
        btnShareDiary = findViewById(R.id.btn_share_diary);
        tvDiaryContent = findViewById(R.id.tv_diary_content);
        progressBar = findViewById(R.id.progress_bar);

        btnGenerateToday.setOnClickListener(v -> generateTodayDiary());
        btnShareDiary.setOnClickListener(v -> shareDiary());
    }

    private void generateTodayDiary() {
        String userMood = etUserMood.getText().toString().trim();

        progressBar.setVisibility(View.VISIBLE);
        tvDiaryContent.setText("正在生成日记...");

        aiManager.generateDiaryForToday(userMood, new AI.DiaryGenerationCallback() {
            @Override
            public void onSuccess(String generatedDiaryText) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    tvDiaryContent.setText(generatedDiaryText);
                    Toast.makeText(AiDiaryActivity.this, "日记生成成功", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onFailure(String errorMessage) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    tvDiaryContent.setText("生成失败: " + errorMessage);
                    Toast.makeText(AiDiaryActivity.this, "生成失败", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void shareDiary() {
        String diaryContent = tvDiaryContent.getText().toString();
        if (diaryContent.isEmpty() || diaryContent.contains("正在生成")) {
            Toast.makeText(this, "请先生成日记", Toast.LENGTH_SHORT).show();
            return;
        }

        android.content.Intent shareIntent = new android.content.Intent(android.content.Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "AI生成日记");
        shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, diaryContent);

        startActivity(android.content.Intent.createChooser(shareIntent, "分享日记"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}