// model/AIResponse.java
package com.example.can301_cw1_test.model;

public class AIResponse {
    private String generatedText;     // AI生成的日记文本
    private String status;            // success/error
    private String errorMessage;      // 错误信息

    // 构造函数
    public AIResponse() {}

    public AIResponse(String generatedText, String status, String errorMessage) {
        this.generatedText = generatedText;
        this.status = status;
        this.errorMessage = errorMessage;
    }

    // Getter和Setter
    public String getGeneratedText() { return generatedText; }
    public void setGeneratedText(String generatedText) { this.generatedText = generatedText; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }

    // 工具方法
    public boolean isSuccess() {
        return "success".equals(status) && generatedText != null && !generatedText.isEmpty();
    }
}